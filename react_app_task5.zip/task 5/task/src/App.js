import './App.css';
import Age from './components/age';
function App() {
  return (
    <div>
      <Age/>
    </div>
  );
}

export default App;