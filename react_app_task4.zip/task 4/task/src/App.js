import Table from './components/table';
import './App.css';

function App() {
  return (
    <div>
      <Table/>
    </div>
    );
}

export default App;